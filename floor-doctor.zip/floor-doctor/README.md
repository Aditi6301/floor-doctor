# Floor Doctor

TAMU Datathon: Best Use of Databricks + Dashboard Royale.

A Databricks system that finds out whether The Gilded Ace's lowest-earning slot machines are
unlucky, badly placed, or broken, picks how to spend $100,000, and traces every recommendation
back to its evidence. Results are shown in a public Streamlit dashboard.

## Folders
| Folder | Owner | Work |
|---|---|---|
| `p1_downtime_pipeline/` | Person 1 | Pipeline, quality rules, leak clues, downtime (Q3), job, lineage |
| `p2_machine_verdicts/` | Person 2 | Bottom 10, luck simulation, moved machines, verdicts (Q1) |
| `p3_demand_forecast/` | Person 3 | Demand (Q2), forecast model + MLflow |
| `p4_players_comps/` | Person 4 | Players (Q4), comps (Q5), Genie |
| `app/` | Everyone | Streamlit dashboard (each person owns their page files) |

See `RULES.md` before writing any code.
