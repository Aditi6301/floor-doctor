# Team Rules

## 1. Where to save
- Shared raw tables (read-only, never change): `workspace.casino.bronze_*`
- Your own tables: `workspace.casino.<prefix>_<name>`
  - Person 1: `p1_`  Person 2: `p2_`  Person 3: `p3_`  Person 4: `p4_`
- Work only in your own folder in this repo.

## 2. Money and data rules
- Always use dollars (`_usd` columns). `_cents` columns are integer cents: divide by 100 once.
- Group daily data by `gaming_date` (gaming day = 6 a.m. to 6 a.m.).
- Ratios = ratio of sums: `SUM(house_win_usd) / SUM(coin_in_usd)`. Never average daily ratios.
- Drop rows where `location_id` is empty (machine not on the floor).
- Day length = `scheduled_seconds` from `calendar_day` (not 24 hours).
- Missing traffic count = sensor offline (check `counter_status`), not zero.
- Comp cost is already inside cogs. Subtract it once.
- Model: train Jan-Apr 2025, test May-Jun 2025. No future data in features.
- Unusual payouts = "candidate for inspection", never cheating or fraud.

## 3. Claims format (send every finding to Person 4)
| claim_id | question | claim | evidence_table | evidence_query | result | alternative_tested | limitation | confidence | owner |

## 4. Action format ($100K plan)
| action | quantity | targets | cost_usd | expected_benefit_usd | low_estimate | high_estimate | confidence | how_to_measure | owner |

Cost formula:
`quantity x (unit_cost_cents + recurring_cost_cents_per_day x max(0, 30 - lead_days)) / 100`

## 5. Dashboard pages (each person owns their files in app/pages/)
| File | Owner |
|---|---|
| 1_Overview.py, 2_Floor_Map.py, 3_Machine_Case_File.py | Person 2 |
| 4_Downtime.py | Person 1 |
| 5_Demand.py, 6_Model_Validation.py | Person 3 |
| 7_Players_Comps.py | Person 4 |
| 8_Budget_Plan.py | Everyone, at the end |

## 6. Never commit secrets
Tokens go in `app/.streamlit/secrets.toml` (ignored by git) or Streamlit Cloud secrets.
