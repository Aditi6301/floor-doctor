import streamlit as st

st.set_page_config(page_title="Floor Doctor", page_icon="🎰", layout="wide")

st.title("Floor Doctor: Luck, Location, or Leak?")
st.write(
    "The Gilded Ace's manager wants to replace the 10 lowest-earning slot machines. "
    "This dashboard checks whether each one is truly underperforming, or just unlucky, "
    "badly placed, or broken, and shows how we would spend $100,000."
)
st.info("Use the pages in the sidebar. Every finding links to its evidence.")
