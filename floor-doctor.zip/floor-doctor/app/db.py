"""Shared helper: query Databricks tables from any page."""
import streamlit as st
from databricks import sql


@st.cache_data(ttl=600)
def query(q: str):
    with sql.connect(
        server_hostname=st.secrets["DATABRICKS_HOST"],
        http_path=st.secrets["DATABRICKS_HTTP_PATH"],
        access_token=st.secrets["DATABRICKS_TOKEN"],
    ) as conn:
        with conn.cursor() as cur:
            cur.execute(q)
            return cur.fetchall_arrow().to_pandas()


def table(name: str, limit: int | None = None):
    q = f"SELECT * FROM workspace.casino.{name}"
    if limit:
        q += f" LIMIT {limit}"
    return query(q)
