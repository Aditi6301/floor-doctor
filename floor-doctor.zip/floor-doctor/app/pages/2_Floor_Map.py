# Owner: Person 2
import streamlit as st
from db import table

st.title("Floor Map")
st.caption("Owner: Person 2. Replace this placeholder with real content.")

# Example: df = table("p2_verdicts")
# st.dataframe(df)
