# Owner: Person 1
import streamlit as st
from db import table

st.title("Downtime")
st.caption("Owner: Person 1. Replace this placeholder with real content.")

# Example: df = table("p2_verdicts")
# st.dataframe(df)
