# Owner: Person 4
import streamlit as st
from db import table

st.title("Players Comps")
st.caption("Owner: Person 4. Replace this placeholder with real content.")

# Example: df = table("p2_verdicts")
# st.dataframe(df)
