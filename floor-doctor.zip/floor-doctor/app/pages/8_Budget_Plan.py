# Owner: Everyone
import streamlit as st
from db import table

st.title("Budget Plan")
st.caption("Owner: Everyone. Replace this placeholder with real content.")

# Example: df = table("p2_verdicts")
# st.dataframe(df)
